chrome.devtools.panels.create("Tamper", "tamper-16.png", "tamper.html", function(panel){});
